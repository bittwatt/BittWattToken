const BittWattToken = artifacts.require('./BittWattToken.sol');
const Settings = require('../utils/settings');
const BigNumber = web3.BigNumber;


Settings.cap = new BigNumber(600000000 * 1e18);

module.exports = async function(deployer, network) {
    // return deployer.then(() => {
        return deployer.deploy(
            BittWattToken,
            Settings.cap
        );      
    // });
};
