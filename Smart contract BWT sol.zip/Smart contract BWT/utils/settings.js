
var Web3 = require('web3');


let cap;

module.exports = {
    cap :  () => cap
};


