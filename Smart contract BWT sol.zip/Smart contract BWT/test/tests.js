const Token = artifacts.require('./BittWattToken.sol');
const Settings = require('../utils/settings');
const timer = require('./helpers/timer');
const BigNumber = web3.BigNumber;

function isException(error) {
    let strError = error.toString()
    return strError.includes('invalid opcode') || strError.includes('invalid JUMP') || strError.includes('revert')
}

function ensuresException(error) {
    assert(isException(error), error.toString())
}

/** Returns last block's timestamp */
function getBlockNow() {
    return web3.eth.getBlock(web3.eth.blockNumber).timestamp // base timestamp off the blockchain
}

contract(
    'Token',
    (
        [
            owner,
            wallet,
            someGuy,
            someOtherGuy
        ]
    ) => {

        var mToken = null;

        beforeEach('initialize contract', async () => {
            mToken = await Token.new(Settings.cap);
        });

        describe('test logic that', () => {

            it('contracts have been deployed.', async () => {
                assert.notEqual(mToken, null, "token not deployed");
            });

            it('contract starts with token not enabled.', async () => {
                const enabledTransfers = await mToken.enabledTransfers();
                enabledTransfers.should.be.false;
            });

            it('mint() and finishMinting() functions behave correct.', async () => {
                await mToken.mint(someGuy, 1000);
                (await mToken.balanceOf(someGuy)).should.be.bignumber.equal(1000);
                await mToken.finishMinting();
                try {
                    await mToken.mint(someGuy, 1000);
                    assert.fail();
                } catch (e) {
                    ensuresException(e);
                    (await mToken.balanceOf(someGuy)).should.be.bignumber.equal(1000);
                }
            });

            it('disabled tokens cant be transfered, but an enabled token can be.', async () => {
                await mToken.mint(someGuy, 1000);
                try {
                    await mToken.transfer(someOtherGuy, 500, { from: someGuy });
                    assert.fail();
                } catch (e) {
                    ensuresException(e);
                }
                await mToken.enableTransfers();
                await mToken.transfer(someOtherGuy, 400, { from: someGuy });
                (await mToken.balanceOf(someOtherGuy)).should.be.bignumber.equal(400);
                (await mToken.balanceOf(someGuy)).should.be.bignumber.equal(600);

            });

            it('ownership transfer can be done only by calling transfer and claiming', async () => {
                await mToken.transferOwnership(someGuy);
                try {
                    await mToken.enableTransfers({from:someGuy});
                    assert.fail();
                } catch (e) {
                    ensuresException(e);
                }

                await mToken.claimOwnership({from:someGuy});
                await mToken.enableTransfers({from:someGuy});
                (await mToken.enabledTransfers()).should.be.true;
            });

            it('getStatus() function returns the correct status', async () => {
                var cap = Settings.cap;
                await mToken.mint(someGuy, 1300);
                await mToken.transferOwnership(someGuy);
                await mToken.finishMinting()
                await mToken.enableTransfers();
                await mToken.claimOwnership({from:someGuy});

                var statusVector = await mToken.getStatus();

                statusVector[0].should.be.bignumber.equal(cap);
                statusVector[1].should.be.bignumber.equal(1300);
                statusVector[2].should.be.true;
                statusVector[3].should.be.true;
                statusVector[4].should.be.equal(someGuy);

            });

        });
    }
);
